package question4;

import java.util.Scanner;

public class Coordinate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        System.out.print("Please enter maximum x coordinate");
        int x = sc.nextInt();
        System.out.print("Please enter maximum y coordinate");
        int y = sc.nextInt();
        
        for(int i=0; i<=x; i++)
        {
        	//System.out.println(x);
        	for(int j=0; j<=y;j++)
        	{
        		System.out.println(i +","+j);
        	}
        }
	}

}