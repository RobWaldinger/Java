package question7;

public class nestedLoops1
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
	
		for(int i=0; i<=4; i++)
		{
			System.out.println("88888888");
		
		}
	}

}
