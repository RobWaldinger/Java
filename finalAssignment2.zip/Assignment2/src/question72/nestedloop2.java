package question72;

public class nestedloop2
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
	String eight ="";
	String[] pattern = new String[5];
		for(int i=0; i<=4; i++)
		{
			eight += "8";
			pattern[i] = eight;
	//	System.out.println(eight);
		}
		for(int i=3; i>=0; i--)
		{
			System.out.println(pattern[i]);
		}
	}

}