package question5;

public class Except16 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		for(int i=10; i<=20; i+=2)
		{
			if(i == (8*2) )
			{
				continue;
			}
			
			System.out.println(i);
		}
		for(int i=10; i<=20; i+=2)
		{
			if(i == (4*4) )
			{
				continue;
			}
			
			System.out.println(i);
		}
		for(int i=10; i<=20; i+=2)
		{
			if(i % 16 == 0 )
			{
				continue;
			}
			
			System.out.println(i);
		}
	}

}
