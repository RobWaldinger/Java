package question2;

import java.util.Scanner;
public class halvingMachine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner sc = new Scanner(System.in);
	        System.out.print("Please enter an integer");
	        int input = sc.nextInt();
	        int half;
	        if(input <= 0)
	        {
	        	System.out.print("HEY! That's against the rules");
	        }
	        else
	        {
	        	if(input % 2 != 0)
	        	{
	        		input++;
	        		
	        	}
	        	do
	        	{
	        		input = input / 2;
	        		System.out.println("half =" + input);
	        		if(input == 1)
	        		{break;}
	        		if(input % 2 !=0)
	        		{
	        		input++;
	        		 input /= 2;
	        		System.out.println("half =" + input);
	        		}
	        		
	        	}while(input >= 1);
	        		
	        	
	        
	        
	        
	        
	        }
	}
}

