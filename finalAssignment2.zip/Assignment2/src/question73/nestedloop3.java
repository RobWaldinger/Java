package question73;

public class nestedloop3 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		String eight ="";
		String blank="";
		String[] pattern = new String[10];
			for(int i=0; i<=9; i++)
			{
				blank +=" ";	//stores blank spaces
				pattern[i] = blank + eight;  // puts blank spaces in array from highest to lowest
			}
			//array of spaces going from highest to lowsest
			for(int i=8; i>=0; i--)
			{
				System.out.println(" " +pattern[i] + "8");	//add 8 to end for pattern
			}
	}

}
