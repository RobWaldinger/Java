package question6;

import java.util.Scanner;

public class inputOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value1 =0;
        int value2=0;
        String opr="";
        int result=0;
        
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer, operand and another integer.  Seperate each with a space. \n");
        String input = sc.nextLine();
        //String [] value1 = input.split(" ");
        String[] splitStr = input.split("\\s+");
        
        for(int k=0; k < splitStr.length; k++ )
        {
        	if (k ==0)
        	{
        		value1 = Integer.parseInt(splitStr[k]);
        	}
        	else if (k ==1)
        	{
        		opr = splitStr[k];
        	}
        	else if(k ==2)
        	{
        		value2 = Integer.parseInt(splitStr[k]);
        	}
        }
        
        switch(opr)
        {
        case "+" : result = value1 + value2; break;
        
        case "-" : result = value1 - value2;  break;
        
        case "*" : result = value1 * value2;  break;
        
        case "/" : result = value1 / value2;  break;
        }
        System.out.println(value1 + " " + opr + " " + value2 + " = " + result );
        

	
        
	//}
	}
	}
/*
String text = "0123456789hello0123456789";
String match = "hello";
int position = text.indexOf(match);
 
*/