	package question3;

	import java.util.Scanner;

	public class LetterAtATime {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
	        System.out.print("Please enter a message\n");
	        String input = sc.nextLine();
	        char letter;
	        
	        int length = input.length();
	        
	        for(int i=0;i < length;i++)
	        {
	        	letter = input.charAt(i);
	        	System.out.println(i+":"+ letter);
	        }
	        
	        
	        
	        
		}

	}