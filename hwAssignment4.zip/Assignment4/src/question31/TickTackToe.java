package question31;

import java.util.Scanner;

public class TickTackToe 
{

	public static void main(String[] args) 
	{	// declare variables
		int row=3;
		int col=3;
		int turn =1;
		String [][] ticktac = new String [row][col];
		
		for(int i=0;i<ticktac.length; i++)	// draw tic tac toe board
		{
			for(int j=0;j<ticktac.length;j++)
			{
				ticktac[i][j] = "-";	// used - instead of blank space so you can see board.
			}
		}      
		 for(int i = 0; i < ticktac.length; i++) 	// draws tic tac toe board
		{
       
           for(int j = 0; j < ticktac[i].length; j++)
                System.out.printf( ticktac[i][j]);

       			System.out.println();
        }

		 Scanner sc = new Scanner(System.in);
		 do	// loop for user to enter row and column to put mark
		 {
			 
			 System.out.println("Enter row to place  mark on");
			 int r = sc.nextInt();
			 System.out.println("Enter column to place  mark on");
			 int c = sc.nextInt();
			 r--;
			 c--;
			 for(int i=0;i<ticktac.length; i++)
				{
					for(int j=0;j<ticktac.length;j++)
					{
						if(turn % 2 != 0)// condition to make odd turns marked with X
						{
							ticktac[r][c] = "X"; 
							
						}
						else
						{
							ticktac[r][c] = "0";// condition to make even turns marked with 0
							
						}
					}
				}
			 for(int i = 0; i < ticktac.length; i++) // redraws tic tac toe board with new mark
				{
		       
		           for(int j = 0; j < ticktac[i].length; j++)
		                System.out.printf( ticktac[i][j]);
	
		       			System.out.println();
		       			
		       			
		        }
			
			turn++;
		 }while (turn <=9);		// ends program when tic tac toe board is full
		 
	}
}