package question4;

import java.util.Scanner;
//import java.lang.*;

public class TwoDPlane 
{

	public static void main(String[] args) 
	{	// declare variables row for array row, col for array col and x for users row X and y for users col for X
		int row=5;
		int col=5;
		int x=0;
		int y=0;
		String [][] ticktac = new String [row][col];	
		
		System.out.println("==============");
		for(int i=0;i<ticktac.length; i++)
		{
			for(int j=0;j<ticktac.length;j++)	// loop that draws 0's and 1 X where user moved
			{
				ticktac[x][y] = " "+ "X" +" ";
				ticktac[i][j] = " "+ "0" + " ";
			}
		}    
	//	ticktac [x][y] = " "+"X"+" ";
		 for(int i = 0; i < ticktac.length; i++) 
		{
       
           for(int j = 0; j < ticktac[i].length; j++)
                System.out.printf( ticktac[i][j]);

       			System.out.println();
        }

        System.out.println("==============");
        Scanner sc = new Scanner(System.in);
        while(x >= 0 && x <=4 || y >=0 && y >=4) {	// condition unnecessary because of System.exit
		System.out.println("Which direction would you like to move?");
		
		String move = sc.nextLine();
		
		
		if (move.equals("down") )
		{	
			if(x == 4)// prevents array from going out of bounds exception and exits program
			{
				System.out.println("Error: You cannot move there from your current position\nExiting program...");
				
				System.exit(0);
			}
			ticktac[x][y] =" "+ "0"+ " ";	// current position turns to 0 as user moves 
			x++;
			System.out.println("==============");
			 for(int i = 0; i < ticktac.length; i++) // loop that draws 0's and 1 X where user moved
				{
				 
		           for(int j = 0; j < ticktac[i].length; j++)	
		           {
					 		ticktac[x][y] = " "+ "X" +" ";
					 
		                System.out.printf( ticktac[i][j]);
		           }
		       			System.out.println();
		        }
			
			 System.out.println("==============");
		}
		else if(move.equals("right"))	// else if condition move right
		{	
			if( y==4)
			{
				System.out.println("Error: You cannot move there from your current position\nExiting program...");
				System.exit(0);
			}
			ticktac[x][y] =" "+ "0"+ " ";// current position turns to 0 as user moves 
			y++;
			System.out.println("==============");
			 for(int i = 0; i < ticktac.length; i++) // loop that draws 0's and 1 X where user moved
				{
				 
		           for(int j = 0; j < ticktac[i].length; j++)	
		           {
					 		ticktac[x][y] = " "+ "X" +" ";
					 
		                System.out.printf( ticktac[i][j]);
		           }
		       			System.out.println();
		        }
			
			 System.out.println("==============");
		}
		else if(move.equals("up"))		// else if condition moves up
		{	
			if(x==0)	// prevents array from going out of bounds exception and exits program
			{
				System.out.println("Error: You cannot move there from your current position\nExiting program...");
				System.exit(0);
			}
			ticktac[x][y] =" "+ "0"+ " ";// current position turns to 0 as user moves 
			x--;
			System.out.println("==============");
			 for(int i = 0; i < ticktac.length; i++) 
				{
				 	
		           for(int j = 0; j < ticktac[i].length; j++) // loop that draws 0's and 1 X where user moved
		           {
					 		ticktac[x][y] = " "+ "X" +" ";
					 
		                System.out.printf( ticktac[i][j]);
		           }
		       			System.out.println();
		        }
			
			 System.out.println("==============");
		}
		else if(move.equals("left")) // else if condition moves left
		{	
			if(y == 0  )	// prevents array from going out of bounds exception and exits program
			{
				System.out.println("Error: You cannot move there from your current position\nExiting program...");
				System.exit(0);
			}
			ticktac[x][y] =" "+ "0"+ " ";	// current position turns to 0 as user moves 
			
			y--;
			System.out.println("==============");	
			 for(int i = 0; i < ticktac.length; i++) // loop that draws 0's and 1 X where user moved
				{
				 
		           for(int j = 0; j < ticktac[i].length; j++)
		           {
					 		ticktac[x][y] = " "+ "X" +" ";
					 
		                System.out.printf( ticktac[i][j]);
		           }
		       			System.out.println();
		        }
			 System.out.println("==============");
		
		}
			
        }
	}

}
